module.exports = [
  {"username":"uat2015@readerplus.com","password":"R3@d3r+","name":"Teacher1 SA","gender":"U", "countryCode" : "SA"},
  {"username":"devteacher@readerplus.com","password":"R3@d3r+","name":"Teacher2 SA","gender":"U", "countryCode" : "SA"}
]
