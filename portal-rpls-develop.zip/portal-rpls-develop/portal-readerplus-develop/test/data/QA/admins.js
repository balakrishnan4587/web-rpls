module.exports = [
  {"username":"devadmin@readerplus.com","password":"R3@d3r+","name":"Admin SA","gender":"U", "countryCode" : "SA"}
]
