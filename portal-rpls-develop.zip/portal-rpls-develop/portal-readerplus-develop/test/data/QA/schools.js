module.exports = {
  e2e : {
    "name": "Reader Dev School"
  },
  qa : {
    "name": "Reader Dev School"
  }
}