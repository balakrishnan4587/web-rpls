module.exports = [{
    "username": "jozz.hart@pearson.com",
    "password": "p4ssw0rd",
    "name": "Jozz Hart",
    "firstName": "Jozz",
    "lastName": "Hart",
    "email": "jozz.hart@pearson.com",
    "roles": ["teacher"],
    "gender" : "male",
    "countryCode" : "US"
  },
  {
    "username": "mehdi.avdi@pearson.com",
    "password": "p4ssw0rd",
    "name": "Mehdi Avdi",
    "firstName": "Mehdi",
    "lastName": "Avdi",
    "email": "mehdi.avdi@pearson.com",
    "roles": ["teacher"],
    "gender" : "male",
    "countryCode" : "US"
  },
  {
    "username": "janesmith@school",
    "password": "p4ssw0rd",
    "name": "Jane Smith",
    "firstName": "Jane",
    "lastName": "Smith",
    "email": "janesmith@school",
    "roles": ["teacher"],
    "gender" : "female",
    "countryCode" : "US"
  }
]
