module.exports = [{
    "username": "manik@ny.com",
    "password": "p4ssw0rd",
    "name": "Manik Kakar",
    "firstName": "Manik",
    "lastName": "Kakar",
    "email": "manik@ny.com",
    "roles": ["student"],
    "gender" : "male",
    "sin" : "1234xxxx1234",
    "countryCode" : "US"
  },
  {
    "username": "test@pearson.com",
    "password": "p4ssw0rd",
    "name": "test two",
    "firstName": "test",
    "lastName": "two",
    "email": "test@pearson.com",
    "roles": ["student"],
    "gender" : "male",
    "sin" : "1234yyyy1234",
    "countryCode" : "US"
  },
  {
    "username": "geetha.muthyam@pearson.com",
    "password": "p4ssw0rd",
    "name": "Geetha Muthyam",
    "firstName": "Geetha",
    "lastName": "Muthyam",
    "email": "geetha.muthyam@pearson.com",
    "roles": ["student"],
    "gender" : "female",
    "sin" : "1234zzzz1234",
    "countryCode" : "US"
  },
  {
    "username": "billy.bob@pearson.com",
    "password": "p4ssw0rd",
    "firstName": "Billy",
    "lastName": "Bob",
    "email": "billy.bob@pearson.com",
    "roles": ["student"],
    "gender" : "male",
    "countryCode" : "US"
  }]
