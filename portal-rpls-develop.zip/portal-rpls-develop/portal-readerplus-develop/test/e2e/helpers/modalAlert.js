var commands = {};

module.exports = {
  url: 'http://localhost:3001',
  commands: [commands],
  elements: {
    alert: {
      selector: '.modal-content .alert div span'
    }
  }
};
