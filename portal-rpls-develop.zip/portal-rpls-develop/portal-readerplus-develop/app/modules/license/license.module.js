'use strict';

angular.module('app.license', [])
.controller('LicenseCtrl', function ($scope, LicenseService, $stateParams, $modal) {

});
