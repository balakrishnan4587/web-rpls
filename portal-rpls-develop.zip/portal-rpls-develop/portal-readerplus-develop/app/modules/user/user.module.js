'use strict';

angular.module('app.user', [])
.controller('UserCtrl', function ($scope, UserService, $stateParams, $modal) {

});
