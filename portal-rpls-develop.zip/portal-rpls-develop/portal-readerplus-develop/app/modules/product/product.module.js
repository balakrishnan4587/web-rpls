'use strict';

angular.module('app.product', [])
.controller('ProductCtrl', function ($scope, ProductService, $stateParams, $modal) {

});
