'use strict';

angular.module('app.schoolDashboard')
.factory('DashboardService', function ($q, $http) {

  return this;

});


