'use strict';

angular.module('app.admin')
.factory('AdminService', function () {

  return this;

});


