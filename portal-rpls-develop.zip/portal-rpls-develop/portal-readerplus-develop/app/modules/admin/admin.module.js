'use strict';

angular.module('app.admin', [])
.controller('AdminCtrl', function () {

});
