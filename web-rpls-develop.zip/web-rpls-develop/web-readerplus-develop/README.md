# web-readerplus

## Quick start

install ```gulp```:

```npm install -g gulp```

Then ```cd``` into directory and run ```npm install```

To start the app run ```gulp```

Open ```localhost:3000``` you should see the dashboard

=======
## Known issues

When running on OSX, if the ```gulp`` task returns a ```EMFILE``` error run the following command in the terminal: ```ulimit -n 2560```
refs/heads/develop
