var Boom = require('boom');
var Hapi = require('hapi');
var Inert = require('inert');
var h2o2 = require('h2o2');
var rest = require('request');
var config = require('../configuration');
var logger = require('../logger');
var glsURL = config.get('gls:url');
var foxitURL = config.get('foxit:url');
var appid = config.get('gls:appid');
var secureCookie = config.get('cookie:secure');
//Foxit protected URIs
var apiPath ='/foxit-webpdf-web/api/';
var assertPath ='/foxit-webpdf-web/asserts/';

options = {
  cors : true,
  timeout : {
    socket : false
  }
}

// Create a server with a host and port
var server = new Hapi.Server();
server.connection({
  host: '0.0.0.0',
  port: process.env.PORT || 3000,
  routes: {
    cors: {
      origin : ['*'],
      headers : ['Authorization', 'Content-Type', 'If-None-Match', 'appid', 'token']
    }
  }
});
logger.info('Cookie isSecure ='+secureCookie);

//predefine the cookie with name 'data'
server.state('data', {
    ttl: null,
    isSecure: secureCookie, //set as false for http access
    isHttpOnly: true,
    path: '/foxit-webpdf-web',
    encoding: 'base64json',
    clearInvalid: false,
    strictHeader: true
});

server.register(Inert, function () {});
server.register(h2o2, function () {});
logger.info('Using GLS URL ='+glsURL);
logger.info('Using Foxit URL ='+foxitURL);
logger.info('App id ='+appid);

server.route([
  {
     method: ['GET'],
     path: '/logout',
     handler: function (request, reply) {
         logger.info('About the clear cookie and logout');
         reply.unstate('data');
         reply('Logged out');
     }
  },
  {
    method: ['GET','POST','OPTIONS'],
    path: '/foxit-webpdf-web/{path*}',
    handler: {
        proxy: {
          mapUri: function (request, callback) {
          var path = request.url.path;
          logger.info(path);
            if(request.method !== 'options' && (path.slice(0,assertPath.length) === assertPath || path.slice(0,apiPath.length) === apiPath)){
              logger.info('Via auth proxy');
               var token = request.headers.token;
               if(!token && request.state.data){
                 token = request.state.data.token || '';
               }
               var options = {
                 url: glsURL + '/authorize',
                 json: true,
                 headers : {
                   appid : appid,
                   token : token
                 }
               };
               logger.info(options);
               rest.get(options, function(err, res, body) {
                 logger.info(body);
                 if(res.statusCode === 200){
                   callback(null, foxitURL + path);
                 } else{
                   callback(Boom.unauthorized('Invalid auth information'));
                 }
               });
            }else{
              logger.info('Via direct proxy');
              callback(null, foxitURL + path);
            }
          },
          passThrough: true
        }
    }
  },
  { method: '*', path: '/{path*}', handler : { directory: { path: './dist', listing: true, index: true }}}
]);

server.ext('onPreResponse', function (request, reply) {
  if ( typeof request.response.statusCode !== 'undefined') {
    if(request.headers.token && !request.state.data  && !(request.url.path === '/logout')){
      logger.info('Setting cookie');
      var ses = {};
       ses.token=request.headers.token;
       //set the token info in cookie with 'data' as name
       reply.state('data', ses);
    }
    return reply.continue();
  }
  else{
    reply.redirect("/");
  }
});

module.exports = server;
