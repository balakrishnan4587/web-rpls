var gulp = require('gulp');
var assets = require("gulp-assets");
var browserify = require('browserify');
var babelify = require('babelify');
var concat = require('gulp-concat');
var less = require('gulp-less');
var min = require('gulp-usemin');
var minifyCSS = require('gulp-minify-css');
var source = require('vinyl-source-stream');
var shell = require('gulp-shell');
var watch = require('gulp-watch');
var nightwatch = require('gulp-nightwatch');
var livereload = require('gulp-livereload');
var notify = require('gulp-notify');
var mocha = require('gulp-mocha');
var uglify = require('gulp-uglify');

gulp.task('seed', function() {
  return require('./test/seed/').start();
});

gulp.task('browserify', function() {
  browserify({
    entries : ['./src/js/main.js'],
    debug : true})
  .transform('babelify', {presets: ['es2015', 'react', 'stage-0']})
  .bundle()
  .on('error',  notify.onError('Error: <%= error.stack %>'))
  .pipe(source('./main.js'))
  .pipe(gulp.dest('dist/js'));
});

gulp.task('less', function () {
  return gulp.src('./src/styles/main.less')
  .pipe(less({
    paths: ['src/styles']
  }))
  .pipe(min({
    cssmin: true
  }))
  .pipe(gulp.dest('./src/assets/css'));
});

gulp.task('cssmin', function (cb) {
  return gulp.src('src/index.html')
    .pipe(assets({
        js: false,
        css: true
    }))
    .pipe(minifyCSS())
    .pipe(concat('main.css'))
    .pipe(gulp.dest('dist/assets/css'));
});

gulp.task('copy', function() {
  gulp.src('src/index.html')
    .pipe(gulp.dest('dist'));

  gulp.src('src/assets/**/*.*')
    .pipe(gulp.dest('dist/assets'));

  gulp.src('src/components/**/*.*')
    .pipe(gulp.dest('dist/components'));
});

gulp.task('server', function() {
  var server = require('./index');
});

//  Also starts the webserver
gulp.task('watch', function() {
  livereload.listen();
  gulp.watch('src/**/*', ['browserify', 'less', 'copy']);
});

gulp.task('e2e', function() {
  gulp.src('')
  .pipe(nightwatch({
    configFile: 'test/e2e/nightwatch.json'
  }));
});

gulp.task('unit', function () {
    require('babel/register');
    return gulp.src('test/unit/*.js', {read: false})
      .pipe(mocha({
         compilers: 'js:babel/register'
      }));
});

/* Minify Main.js files with UglifyJS.*/
gulp.task('compress', function() {
  return gulp.src('dist/js/main.js')
    .pipe(uglify())
    .pipe(gulp.dest('dist/uglify'));
});

gulp.task('default', ['server', 'browserify', 'copy', 'watch']);
gulp.task('build', ['browserify', 'less', 'cssmin', 'copy']);
gulp.task('test', ['seed', 'e2e', 'unit']);
