module.exports = {
  url: 'http://localhost:3000',
  elements: {
	  username : 'test_school_admin@pearson.com',
	  password : 'TldE996gbhoO'
  },
	bookshelfLogin: {
	  username : 'reader1.sa@uat.com',
	  password : 'hudson102'		
	}
};