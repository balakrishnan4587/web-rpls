require('babel/register')({
  stage : 0
});

var jsdom = require('jsdom');

global.expect = require('chai').expect;

global.document = jsdom.jsdom('<!doctype html><html><body></body></html>');
//global.window = document.parentWindow;
global.window = document.defaultView;
global.navigator = window.navigator = {};
navigator.userAgent = 'NodeJs JsDom';
global.XMLHttpRequest = window.XMLHttpRequest;
navigator.appVersion = '';
