import React from 'react/addons';
import assert from 'assert';
import Login from '../../src/js/components/login';

let TestUtils = React.addons.TestUtils;

describe('Login component', function(){
  before('render and locate element', function() {
		 
    this.renderedLoginComponent = TestUtils.renderIntoDocument(
      <Login />
    );

    var inputLoginNodes = TestUtils.scryRenderedDOMComponentsWithTag(
      this.renderedLoginComponent,
      'input'
    );
		var buttonLoginNode = TestUtils.findRenderedDOMComponentWithTag(
      this.renderedLoginComponent,
      'button'
    );
		
		this.bodyContent = this.renderedLoginComponent;

		this.inputLoginElement = inputLoginNodes;
		this.buttonLoginElement = buttonLoginNode;
  });
  
  it('<input> should be of type "text"', function() {
    assert(this.inputLoginElement[0].props.id === 'username');
  });

});