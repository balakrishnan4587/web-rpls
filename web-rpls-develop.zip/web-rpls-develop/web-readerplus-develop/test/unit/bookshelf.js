import React from 'react/addons';
import sinon from 'sinon';
import request from 'superagent';
import Bookshelf from '../../src/js/components/bookshelf';
import MyBook from '../../src/js/components/bookshelfitem';
import {Dispatcher} from 'flux';
let assert = require('chai').assert;
let TestUtils = React.addons.TestUtils;

describe('Bookshelf component', function(){
	var bookdata='', requestStub = '';

	beforeEach('setting document',function(){
		require('react/lib/ExecutionEnvironment').canUseDOM = true;		
	});
	before('render and load bookshelf item element and get control on AJAX call', function(done){
		bookdata = {  
			"id":"54c7c4fa3078e7281ce38d42",
			"coverImageURL":{  
				 "id":"54c7c4fa3078e7281ce38d41",
				 "url":"https://s3.amazonaws.com/mobileplatform.static/resources/readerplus/epubs/protected/SA/9780636154636.cover.jpg"
			},
			"title":"Powerful ​Life Orientation",
			"author":"na",
			"uid":"feb0c577b11b48dfb8ea29d5c0f3196b",
			"epubURL":"https://s3.amazonaws.com/mobileplatform.static/resources/readerplus/epubs/protected/SA/9780636154636.zip",
			"encpwd":"Z9CWCVL7/D2Zy+L6mv1jozaopKuGPtjYHX2qh32xIE/mOzkfelTcZ5JSYkfL+JrQ",
			"allowedPageNavigation":"vertical",
			"layout":[  
				 "portrait_single_page",
				 " landscape_single_page"
			]
		};
		bookdata.downloadBook = true;
		requestStub = sinon.stub(request.Request.prototype, 'end').yields(null, bookdata);
		this.renderedBookshelfItemComponent = TestUtils.renderIntoDocument(<MyBook book={bookdata}/>);
		done();
	});
	after('restore control on AJAX call', function(done){
		request.Request.prototype.end.restore();
		done();
	});
	
	it('Check the bookshelf item is loaded or not',function(){
		let bookshelfItemNode = TestUtils.findRenderedDOMComponentWithClass(this.renderedBookshelfItemComponent,'bookshelfItem');
		let bookshelfItemLength= bookshelfItemNode.getDOMNode().childNodes.length;
		expect(bookshelfItemLength).to.be.at.least(2,'bookshelf item should have minimum 2 childnodes');
  });
	
	it('Check the thumbnail image source is available or not',function(){
		let bookThumbnailNode = TestUtils.findRenderedDOMComponentWithClass(this.renderedBookshelfItemComponent,'bookThumbnail');
		let bookThumbnailContent = bookThumbnailNode.getDOMNode().childNodes[0].getAttribute('src');
		assert.notEqual(bookThumbnailContent, '', 'image url is not available');
		expect(bookThumbnailContent).to.match(/\.(jpe?g|png|gif|bmp)$/,'image type should be jpeg or jpg or png or bmp or gif');
  });
	
	it('Check the book title is present or not',function(){
		let bookTitleNode = TestUtils.findRenderedDOMComponentWithClass(this.renderedBookshelfItemComponent,'bookName');
		let bookTitleContent = bookTitleNode.getDOMNode().childNodes[0].nodeValue;
		assert.isNotNull(bookTitleContent,'Booktitle is available');
  });
	
	it('Check the download function is called',function(){
		let bookshelfWrapper = TestUtils.findRenderedDOMComponentWithClass(this.renderedBookshelfItemComponent,'bookshelfItem');
		TestUtils.Simulate.click(bookshelfWrapper.getDOMNode());
		assert.isTrue(this.renderedBookshelfItemComponent.bookdownloaded,'Yes downloading starts');
  });
	
	it("check the bookshelf component work-flow action, store and callback", function () {
		/*
		var myobj = {'body':[bookdata]};
		requestStub.yields(null,myobj);
		var bookobj = new Bookshelf();
		sinon.stub(bookobj,'bookshelfDataFetched').returns(0);
		this.renderedBookshelfComponent = React.render(React.createElement(bookobj));
		console.log('response:'+bookshelfObj.bookshelfDataFetched());
		bookshelfObj.bookshelfDataFetched.restore();
		let AppActions =  require("../../src/js/actions/app.actions");
		AppActions.loadBookshelf();		
		*/
  });
	
});