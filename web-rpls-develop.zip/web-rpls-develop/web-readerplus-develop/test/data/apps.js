module.exports = [{
    "_id": "5487201fbab5214b54f3ecc1",
    "name": "e2e App",
    "platform": "Android",
    "authentication": "saltare",
    "enabled": "true"
  }
]