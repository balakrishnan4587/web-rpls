module.exports = [
  {
    "_id" : "56126692aaf2207d19715374",
    "url" : "https://s3.amazonaws.com/mobileplatform.static/resources/readerplus/epubs/protected/all-about-mummies.cover.png"
  },{
    "_id" : "56126697aaf2207d19715377",
    "url" : "http://ecx.images-amazon.com/images/I/41UwXEqrQ6L.jpg"
  }
]


