module.exports = [{
  "_id" : "56126692aaf2207d19715375",
  "uid" : "fa80d52835824136ba4d7e4192b5512f",
  "title" : "All About Mummies",
  "epubURL" : "https://s3.amazonaws.com/mobileplatform.static/resources/readerplus/epubs/protected/all-about-mummies.zip",
  "coverImageURL" : "56126692aaf2207d19715374",
  "author" : "Dianne Irving",
  "encpwd" : "Z9CWCVL7/D2Zy+L6mv1jozaopKuGPtjYHX2qh32xIE/mOzkfelTcZ5JSYkfL+JrQ",
  "allowedPageNavigation" : "horizontal",
  "layout" : [
      "portrait_single_page",
      " landscape_double_page"
  ]
},{
  "_id" : "56126697aaf2207d19715378",
  "coverImageURL" : "56126697aaf2207d19715377",
  "title" : "Degrees of Flight",
  "author" : "Hedley England",
  "uid" : "7157749f35e44ab49184aaf8b7a0eebe",
  "epubURL" : "http://static.aws.com/book.epub",
  "description" : "some description",
  "allowedPageNavigation" : "vertical",
  "layout" : [
      "portrait_single_page",
      " landscape_double_page"
  ]
}]
