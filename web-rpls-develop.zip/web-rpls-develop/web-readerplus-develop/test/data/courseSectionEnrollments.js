module.exports = [{
    "_id" : "5612668aaaf2207d1971530e",
    "user" : "56126687aaf2207d19715300",
    "courseSection" : "56126686aaf2207d197152ec",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d1971530f",
    "user" : "56126687aaf2207d19715302",
    "courseSection" : "56126686aaf2207d197152ec",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d19715310",
    "user" : "56126688aaf2207d19715304",
    "courseSection" : "56126686aaf2207d197152ec",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d19715311",
    "user" : "56126688aaf2207d19715306",
    "courseSection" : "56126686aaf2207d197152ec",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d19715312",
    "user" : "56126687aaf2207d19715300",
    "courseSection" : "56126686aaf2207d197152ee",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d19715313",
    "user" : "56126687aaf2207d19715302",
    "courseSection" : "56126686aaf2207d197152ee",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d19715314",
    "user" : "56126688aaf2207d19715304",
    "courseSection" : "56126686aaf2207d197152ee",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d19715315",
    "user" : "56126688aaf2207d19715306",
    "courseSection" : "56126686aaf2207d197152ee",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d19715316",
    "user" : "56126687aaf2207d19715300",
    "courseSection" : "56126686aaf2207d197152ef",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d19715317",
    "user" : "56126687aaf2207d19715302",
    "courseSection" : "56126686aaf2207d197152ef",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d19715318",
    "user" : "56126688aaf2207d19715304",
    "courseSection" : "56126686aaf2207d197152ef",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d19715319",
    "user" : "56126688aaf2207d19715306",
    "courseSection" : "56126686aaf2207d197152ef",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d1971531a",
    "user" : "56126687aaf2207d19715300",
    "courseSection" : "56126686aaf2207d197152f0",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d1971531b",
    "user" : "56126687aaf2207d19715302",
    "courseSection" : "56126686aaf2207d197152f0",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d1971531c",
    "user" : "56126688aaf2207d19715304",
    "courseSection" : "56126686aaf2207d197152f0",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d1971531d",
    "user" : "56126688aaf2207d19715306",
    "courseSection" : "56126686aaf2207d197152f0",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d1971531e",
    "user" : "56126687aaf2207d19715300",
    "courseSection" : "56126686aaf2207d197152f1",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d1971531f",
    "user" : "56126687aaf2207d19715302",
    "courseSection" : "56126686aaf2207d197152f1",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d19715320",
    "user" : "56126688aaf2207d19715304",
    "courseSection" : "56126686aaf2207d197152f1",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d19715321",
    "user" : "56126688aaf2207d19715306",
    "courseSection" : "56126686aaf2207d197152f1",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d19715322",
    "user" : "56126687aaf2207d19715300",
    "courseSection" : "56126686aaf2207d197152f2",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d19715323",
    "user" : "56126687aaf2207d19715302",
    "courseSection" : "56126686aaf2207d197152f2",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d19715324",
    "user" : "56126688aaf2207d19715304",
    "courseSection" : "56126686aaf2207d197152f2",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d19715325",
    "user" : "56126688aaf2207d19715306",
    "courseSection" : "56126686aaf2207d197152f2",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d19715326",
    "user" : "56126687aaf2207d19715300",
    "courseSection" : "56126686aaf2207d197152f3",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d19715327",
    "user" : "56126687aaf2207d19715302",
    "courseSection" : "56126686aaf2207d197152f3",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d19715328",
    "user" : "56126688aaf2207d19715304",
    "courseSection" : "56126686aaf2207d197152f3",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d19715329",
    "user" : "56126688aaf2207d19715306",
    "courseSection" : "56126686aaf2207d197152f3",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d1971532a",
    "user" : "56126687aaf2207d19715300",
    "courseSection" : "56126686aaf2207d197152f4",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d1971532b",
    "user" : "56126687aaf2207d19715302",
    "courseSection" : "56126686aaf2207d197152f4",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d1971532c",
    "user" : "56126688aaf2207d19715304",
    "courseSection" : "56126686aaf2207d197152f4",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668aaaf2207d1971532d",
    "user" : "56126688aaf2207d19715306",
    "courseSection" : "56126686aaf2207d197152f4",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668baaf2207d1971532e",
    "user" : "56126687aaf2207d19715300",
    "courseSection" : "56126686aaf2207d197152f5",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668baaf2207d1971532f",
    "user" : "56126687aaf2207d19715302",
    "courseSection" : "56126686aaf2207d197152f5",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668baaf2207d19715330",
    "user" : "56126688aaf2207d19715304",
    "courseSection" : "56126686aaf2207d197152f5",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668baaf2207d19715331",
    "user" : "56126688aaf2207d19715306",
    "courseSection" : "56126686aaf2207d197152f5",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668baaf2207d19715332",
    "user" : "56126687aaf2207d19715300",
    "courseSection" : "56126686aaf2207d197152f6",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668baaf2207d19715333",
    "user" : "56126687aaf2207d19715302",
    "courseSection" : "56126686aaf2207d197152f6",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668baaf2207d19715334",
    "user" : "56126688aaf2207d19715304",
    "courseSection" : "56126686aaf2207d197152f6",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668baaf2207d19715335",
    "user" : "56126688aaf2207d19715306",
    "courseSection" : "56126686aaf2207d197152f6",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668baaf2207d19715336",
    "user" : "56126687aaf2207d19715300",
    "courseSection" : "56126686aaf2207d197152f7",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668baaf2207d19715337",
    "user" : "56126687aaf2207d19715302",
    "courseSection" : "56126686aaf2207d197152f7",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668baaf2207d19715338",
    "user" : "56126688aaf2207d19715304",
    "courseSection" : "56126686aaf2207d197152f7",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668baaf2207d19715339",
    "user" : "56126688aaf2207d19715306",
    "courseSection" : "56126686aaf2207d197152f7",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668baaf2207d1971533a",
    "user" : "56126687aaf2207d19715300",
    "courseSection" : "56126686aaf2207d197152f8",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668baaf2207d1971533b",
    "user" : "56126687aaf2207d19715302",
    "courseSection" : "56126686aaf2207d197152f8",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668baaf2207d1971533c",
    "user" : "56126688aaf2207d19715304",
    "courseSection" : "56126686aaf2207d197152f8",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668baaf2207d1971533d",
    "user" : "56126688aaf2207d19715306",
    "courseSection" : "56126686aaf2207d197152f8",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668baaf2207d1971533e",
    "user" : "56126687aaf2207d19715300",
    "courseSection" : "56126686aaf2207d197152f9",
    "state" : "active",
    "role" : "student"
},{
    "_id" : "5612668baaf2207d1971533f",
    "user" : "56126687aaf2207d19715302",
    "courseSection" : "56126686aaf2207d197152f9",
    "state" : "active",
    "role" : "student"
}]