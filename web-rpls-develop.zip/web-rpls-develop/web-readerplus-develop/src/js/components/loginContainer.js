import React from 'react';
import AppActions from '../actions/app.actions';
import AppStore from '../stores/app.store';
import AppConstants from '../constants/app.constants';
import DataFormatter from './utilities/dataFormatter';
import Localization from './localization';
import Helmet from 'react-helmet'
import Header from './header';
import Login  from './login';
import ErrorConstants from '../constants/error.constants';
import injectTapEventPlugin from 'react-tap-event-plugin';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
// import MyAwesomeReactComponent from './MyAwesomeReactComponent';




var lang = DataFormatter.getLanguage();

class LoginContainer extends React.Component {

state = {
   title: this.props.title,
   fontstyle: this.props.fontstyle,
   ErrorTxt: this.props.content,
   comp_id: Math.floor(Math.random() * 0xFFFF)
 }


 myunload = function(e){
   DataFormatter.setObjectInStorage('curpagepath',window.location.pathname);

   if(location.pathname.trim().indexOf('readBook') >=0)  {
     var curbookpageno = this.sliderObj.getValue();
     DataFormatter.setObjectInStorage('curbookpageno',curbookpageno);
   }
 }

  postvalidation  = () => {
		let username = document.getElementById('username').value.trim();
		let password = document.getElementById('password').value.trim();
		if (!username && !password) {
			this.updateMessage(DataFormatter.getObjectText(Localization, (lang + ".ErrorConstants.Login.NULL_CHECK_BOTH_MESSAGE")));
		}
		else if (username && !password) {
			this.updateMessage(DataFormatter.getObjectText(Localization, (lang + ".ErrorConstants.Login.NULL_CHECK_PASSWORD_MESSAGE")));
		}
		else if (!username && password) {
			this.updateMessage(DataFormatter.getObjectText(Localization, (lang + ".ErrorConstants.Login.NULL_CHECK_USERNAME_MESSAGE")));
		}
		else {
			this.updateMessage('loader');
			AppActions.loginSubmit(username,password);
		};
	}

  logincompletion = () => {
		if(AppStore.response=='failed'){
			this.updateMessage(DataFormatter.getObjectText(Localization, (lang + ".ErrorConstants.Login.FAILURE_MESSAGE")));
		}
		else {
			this.updateMessage(ErrorConstants.Login.SUCCESS_MESSAGE,'success');
		}
	}

logoutCompleted = () => {
    console.log("User Logout ");
    this.context.router.push('/',this.updateMessage);
  }
  updateMessage = function(content,flag){
		if(flag=='success'){
      console.log('login Container getUser calling-> ', this.state.comp_id);
			AppActions.getUser();
		}
		else if(flag === "logout")
		{
			this.setState({ErrorTxt:content,FontStyle:'greenTxt'});
		}
		else{
      if(!content) {
        this.setState({ErrorTxt: "You have been logged out successfully.",FontStyle:'greenTxt'});  
      } else {
        this.setState({ErrorTxt: content,FontStyle:'errTxt'});  
      }			
		}
	}

  getUserCompleted = () => {
    console.log('login Container getUser completed', this.state.comp_id);
		this.context.router.push('/bookshelf');
	}

  render() {
    console.log('LoginContainer render called', __dirname );
    return (
		<div>
    <Helmet title="Login"/>
    <MuiThemeProvider>
    <Login ErrorTxt={this.state.ErrorTxt} FontStyle={this.state.FontStyle} />
    </MuiThemeProvider>
		</div>
    );
  }

  componentDidMount(){
    if(window.localStorage){
      var storedpath = DataFormatter.getObjectInStorage('curpagepath');
      console.log('storedpath -->', storedpath);
      AppActions.authorizeUser();
      if(storedpath !== null) {       
            this.context.router.push(storedpath);                  
      }else{
        if(DataFormatter.getKeyFromObject('userInformation','userToken') != null) {
          this.context.router.push('/bookshelf');
        }
      }
    }
    var logoutOrNot = DataFormatter.getObjectInStorage('loginscreenmessage');
    DataFormatter.setObjectInStorage('loginscreenmessage', false);
    if(logoutOrNot) {
      this.setState({
        ErrorTxt : DataFormatter.getObjectInStorage('message'),
        FontStyle:'greenTxt'
      });
    }
    DataFormatter.setObjectInStorage('message', '')
    var curpagepath = DataFormatter.getObjectInStorage('curpagepath');
    var curpageno   = DataFormatter.getObjectInStorage('curbookpageno');
    if(curpagepath !== null) {
      localStorage.removeItem('curpagepath');
    };
    window.addEventListener('unload', this.myunload);
    DataFormatter.createAWSSession();
    DataFormatter.sendAWSEvent("screen", { "action": "open" , "name" : "login" , "user_id": "unavailable"});
  }

  componentWillMount() {  
       try{
    injectTapEventPlugin();  
  }catch(e){

  }   
    AppStore.on(AppConstants.EventTypes.USER_LOGOUT_COMPLETE, this.logoutCompleted);
 		AppStore.on(AppConstants.EventTypes.LOGIN_VALIDATE_COMPLETE, this.postvalidation);
    AppStore.on(AppConstants.EventTypes.LOGIN_SUBMIT_COMPLETE, this.logincompletion);
    AppStore.on(AppConstants.EventTypes.GET_USER_COMPLETE, this.getUserCompleted);
  }

  componentWillUnmount() {
    console.log('login container unmounted-> ', this.state.comp_id);
    	window.removeEventListener('unload', this.myunload);      
      // AppStore.removeListener(AppConstants.EventTypes.USER_LOGOUT_COMPLETE, this.logoutCompleted);
      AppStore.removeListener(AppConstants.EventTypes.LOGIN_VALIDATE_COMPLETE, this.postvalidation);
      AppStore.removeListener(AppConstants.EventTypes.LOGIN_SUBMIT_COMPLETE, this.logincompletion);
      AppStore.removeListener(AppConstants.EventTypes.GET_USER_COMPLETE, this.getUserCompleted);
  	}

};

LoginContainer.defaultProps = {
    title: DataFormatter.getObjectText(Localization, (lang + ".PageTitles.Login")),
   fontstyle: 'errTxt',
   ErrorTxt: ''
 }

LoginContainer.contextTypes= {
  router: React.PropTypes.object.isRequired
}
export default LoginContainer;
