import keyMirror from 'fbjs/lib/keyMirror';

export default {   

  enus:{
    PageTitles:{
    Login:"Login",
    Bookshelf:"My Bookshelf",
    ReadBook:"Read Book"
   },
    UserMessages:{
    UserLoggedOut:"You have been logged out successfully."
   },
   PageText:{
    Login:"Sign in",
    Highlight: "Highlight",
    UserName: "Username",
    PassWord: "Password",
    Note: "Note",
    NotesAndHighlight: "Notes and Highlights",
    NoHighlights: "You have not taken any Highlights or Notes for this Book",
    NoBookmarks: "You have not placed any bookmarks in this book",
    Logout: "Logout",
    Bookmarks: "Bookmarks",
    TakeNote: "Take Note",
    TOC: "Table of Contents",
    Save: "Save",
    Cancel: "Cancel",
    Chapter: "Chapter",
    Of: "of",
    AddNote: "Add Note"
   },
   AccesibilityText:{
    Original:"Original",
    Arial:"Arial",
    Courier:"Courier", 
    Times:"Times", 
    Default:"Default",
    Night:"Night",
    Sepia:"Sepia"
   },   
   ErrorConstants:{
        SessionExpired:"Your session has expired. Please login again to continue.",
        "Login":{
        'NULL_CHECK_BOTH_MESSAGE' : 'Please enter your username and password',
        'NULL_CHECK_USERNAME_MESSAGE' : 'Please enter your username',
        'NULL_CHECK_PASSWORD_MESSAGE' : 'Please enter your password',
        'FORMAT_CHECK_MESSAGE' : 'Please provide valid username',
        'SUCCESS_MESSAGE' : 'You have successfully logged in',
        'FAILURE_MESSAGE' : 'Invalid username and/or password'
        }
      }
    } ,

  it:{
    PageTitles:{
    Login:"Accedi",
    Bookshelf:"La mia libreria",
    ReadBook:"Read Book"
   },
    UserMessages:{
    UserLoggedOut:"Sei stato disconnesso con successo."
   },
   PageText:{
    Login:"Accedi",
    Highlight: "Evidenzia",
    NoHighlights: "Non hai preso alcuna note o mette in evidenza per questo libro",
    NoBookmarks: "Non hai ancora aggiunto segnalibri in questo libro",
    Note: "Nota",
    UserName: "Username",
    PassWord: "Password",
    NotesAndHighlight: "Note ed evidenziazioni",
    Logout: "Disconnettersi",
    Bookmarks: "Segnalibri",
    TakeNote: "Nota",
    TOC: "Indice",
    Save: "Salva",
    Cancel: "Annulla",
    Chapter: "Capitolo",
    Of: "di",
    AddNote: "Aggiungi una nota"
   },
  AccesibilityText:{
    Original:"Originale",
    Arial:"Arial",
    Courier:"Courier", 
    Times:"Times", 
    Default:"Predefinito",
    Night:"Night",
    Sepia:"Sepia"
   },
   ErrorConstants:{

        SessionExpired:"La tua sessione è scaduta. Effettua il login per continuare.",
        "Login":{
        'NULL_CHECK_BOTH_MESSAGE' : 'Inserisci la tua username e password',
        'NULL_CHECK_USERNAME_MESSAGE' : 'Inserisci la tua username',
        'NULL_CHECK_PASSWORD_MESSAGE' : 'Inserisci la tua password',
        'FORMAT_CHECK_MESSAGE' : 'Please provide valid username',
        'SUCCESS_MESSAGE' : 'You have successfully logged in',
        'FAILURE_MESSAGE' : 'Dati di accesso errati'
        }
      }
  }
};
/***
LOGIN_VALIDATE - client side validation
LOGIN_VALIDATE_COMPLETE - after completing client side validation
LOGIN_SUBMIT - passing data to server
LOGIN_SUBMIT_COMPLETE - getting response (success/failure) from server
BOOKSHELF_LOAD_COMPLETE - bookshelf loading is complete
***/
