import React from 'react';

class ErrorComponent extends React.Component {
  render() {
		var loader;
    if (this.props.contentDD=="loader") {
			// loader = <span><img src='assets/images/loading-icon.gif'/></span>;
    } else {
			loader = <span id='loginStatus' className={this.props.fontstyleDD} ref='errTxt'>{this.props.contentDD}</span>;
    }	
    return (
			<div className="statusDisplay">
			{loader}
			</div>
    );
  }
};

export default ErrorComponent;





