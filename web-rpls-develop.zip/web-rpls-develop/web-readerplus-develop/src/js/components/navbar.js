import React from 'react';
import AppActions from '../actions/app.actions';
import AppConstants from '../constants/app.constants';
import DataFormatter from './utilities/dataFormatter';
import Localization from './localization';
import AppStore from '../stores/app.store';
import AppBar from 'material-ui/AppBar';
import IconButton from 'material-ui/IconButton';
import Popover from 'material-ui/Popover';
import IconMenu from 'material-ui/IconMenu';
import MenuItem from 'material-ui/MenuItem';
import Paper from 'material-ui/Paper';
import Menu from 'material-ui/Menu';
import MoreVertIcon from 'material-ui/svg-icons/navigation/more-vert';
import NavigationClose from 'material-ui/svg-icons/navigation/close';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import injectTapEventPlugin from 'react-tap-event-plugin';
try{
    injectTapEventPlugin();  
  }catch(e){

  } 

const style = {
  display: 'inline-block',
  margin: '16px 32px 16px 0',
};   

var lang = DataFormatter.getLanguage();

class PageNavbar extends React.Component {
  constructor() {
    super();
  }
  state = {
      isBookmarked: false,
      open: false
  };

  componentDidMount = function() {
    if(document.querySelector('.navbar_right_icon')) {
      if(Object.prototype.toString.call(window.HTMLElement).indexOf('Constructor') > 0) {
        $('.navbar_right_icon').bind('mousedown', this.handleTouchTap);
      }else {
        document.querySelector('.navbar_right_icon').addEventListener('click', this.handleTouchTap);    
      }    
    }        
    if(document.querySelector('.readerplus_appbar')) {
      document.querySelector('.readerplus_appbar').addEventListener('click', this.handleTouchTap);
    }
    if(document.querySelector('.signout_option')) {
      document.querySelector('.signout_option').addEventListener('click', this.logout);
    }
    if(document.querySelector('.bookshelfMasterContainer')) {
      document.querySelector('.bookshelfMasterContainer').addEventListener('click', this.handleTouchTap);
    }
  }

  logout = function() {
    var logoutText = lang + ".UserMessages.UserLoggedOut";
    var logoutMessage = DataFormatter.getObjectText(Localization, logoutText);
    AppActions.logoutUser({
      action:"logout",
      message:logoutMessage ? logoutMessage : AppConstants.UserMessages.UserLoggedOut
    });
  }

  handleTouchTap = (event) => {
    console.log("Right Icon Clicked");
    // This prevents ghost click.
    event.preventDefault();
    if(event.currentTarget.classList.contains("navbar_right_icon")) {
       try{
      if(document.querySelector('.logout_menu').style.visibility=="" || document.querySelector('.logout_menu').style.visibility =="hidden"){
      document.querySelector('.logout_menu').style.visibility = "visible";  
      document.querySelector('.signout_option').style.visibility = "visible";
      document.querySelector('.user_name').style.visibility = "visible";
    }else{
      document.querySelector('.logout_menu').style.visibility = "hidden";
      document.querySelector('.signout_option').style.visibility = "hidden";
      document.querySelector('.user_name').style.visibility = "hidden";      
    }
      event.cancelBubble = true;
    }catch(e){

    }
    } else {
      document.querySelector('.logout_menu').style.visibility = "hidden";
      document.querySelector('.signout_option').style.visibility = "hidden";
      document.querySelector('.user_name').style.visibility = "hidden";
    }
  };

  handleRequestClose = () => {
    this.setState({
      open: false,
    });
  };

  render() {
  console.log(DataFormatter.getKeyFromObject("userInformation", "name"));
    return (
      <div>
      <MuiThemeProvider>
         <AppBar showMenuIconButton={false} className="readerplus_appbar" title="Reader +"
    
    iconElementRight={
       <IconMenu  id="navbar_right_icon" className ="navbar_right_icon"
        iconButtonElement={
          <IconButton ><MoreVertIcon /></IconButton>
        }
        targetOrigin={{horizontal: 'right', vertical: 'top'}}
        anchorOrigin={{horizontal: 'right', vertical: 'top'}}
      >
       
      </IconMenu>    
    } > </AppBar>
      
  </MuiThemeProvider>
  <MuiThemeProvider>
    <Paper className="logout_menu" visibility="hidden"  style={style}>
      <Menu>
        <MenuItem id="user_name" className= "user_name" primaryText={DataFormatter.getKeyFromObject("userInformation", "name")} />
        <MenuItem id="signout_option" className= "signout_option" primaryText="Sign Out" />
      </Menu>
    </Paper>
    </MuiThemeProvider>
      </div>
    );
  }
  
};


PageNavbar.contextTypes= {
  router: React.PropTypes.object.isRequired
}
export default PageNavbar;
