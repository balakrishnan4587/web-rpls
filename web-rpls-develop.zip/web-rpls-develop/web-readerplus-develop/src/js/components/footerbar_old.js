import React from 'react';
import Slider from 'bootstrap-slider';
import DataFormatter from './utilities/dataFormatter';
import Localization from './localization';


var lang = DataFormatter.getLanguage();

let sliderObj, sliderOptions = {};
let oldSliderValue = 1;

class Footer extends React.Component {
	state = {
		maxValue: 0
	};
	componentDidUpdate = function() {
		// Create an instance only when the slider is to be shown.
		if (this.props.isSliderShown) {
			// If the slider object is not created, then create it.
			if (!sliderObj || Object.keys(sliderObj).length === 0) {
				sliderOptions.id = this.props.sliderID;
				sliderOptions.step = this.props.step;
				sliderOptions.isPercentageSlider = this.props.isPercentageSlider;

				if (!this.props.isPercentageSlider) {
					sliderOptions.max = this.props.totalPages;
					sliderOptions.min = 1;
					sliderOptions.value = this.props.sliderValue;
				}
				else {
					sliderOptions.max = 100;
					sliderOptions.min = 0;
					sliderOptions.value = this.props.sliderValue;
				}
				// Formatting function that will determine the slider text.
				sliderOptions.formatter = function(value) {
					document.getElementById("curProgress").textContent = value;
					if (!sliderOptions.isPercentageSlider) {
						return DataFormatter.getObjectText(Localization, (lang + ".PageText.Chapter")) + " " + value;
					}
					else {
						return value + "% of book navigated";
					}
				}
				this.setState({
					maxValue: sliderOptions.max
				})
				// Initiate the slider.
				sliderObj = new Slider("#" + sliderOptions.id, sliderOptions);
				sliderObj.on('slideStop', this.loadNextPage);
			}
			// Else listen for a value change and set if required.
			else {
				// Update slider value only if the value is different from the old value.
				if (oldSliderValue !== this.props.sliderValue) {
					oldSliderValue = this.props.sliderValue;
					sliderObj.setValue(this.props.sliderValue);
				}
			}
		}
	}
	render() {
		// Cater to an absolute or percentage value.
		var percentageNavigated = Math.floor((this.props.sliderValue/this.props.totalPages) * 100);
		var percentageLabel = this.props.isPercentageSlider? "" :percentageNavigated +"% - ";
		var chapterLabel = this.props.isPercentageSlider? "" :percentageLabel + DataFormatter.getObjectText(Localization, (lang + ".PageText.Chapter")) + " ";
		var progressLabel = this.props.isPercentageSlider?
		" % of book navigated" :" " + DataFormatter.getObjectText(Localization, (lang + ".PageText.Of")) + " " + this.state.maxValue ;
		// Render only if the slider is supposed to be rendered.
		if (this.props.isSliderShown) {
			return ( < div className = "footerBar" >
			< div className = "sliderContainer" >
			< input id = {
				this.props.sliderID
			}
			type = "text" / >
			< div className = "sliderStatusMsg"
			id = "sliderStatusMsg" >{chapterLabel}<span id = "curProgress" ></span>{progressLabel}</div>
			< /div>
			</div >
		);
	}
	return null;
}
/*
Clean up slider instances.
*/
componentWillUnmount() {
	 sliderObj = sliderOptions = {};
	 oldSliderValue = 1;
}
/*
This method is fired when the user stops moving the
slider handle to set a new value.
*/
loadNextPage = (valueObj) => {
	// Trigger the callback method.
	if (DataFormatter.isFunction(this.props.valueChangedCallback)) {
		this.props.valueChangedCallback(valueObj);
	} 
	try{
	 document.querySelector('.accessibilityContainer').style.visibility = "hidden";
	}catch(e) {
  }
}
};
export default Footer;
