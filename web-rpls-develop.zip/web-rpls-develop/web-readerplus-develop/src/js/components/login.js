import React from 'react';
import AppActions from '../actions/app.actions';
import AppStore from '../stores/app.store';
import AppConstants from '../constants/app.constants';
import DataFormatter from './utilities/dataFormatter';
import Localization from './localization';
import TextField from 'material-ui/TextField';
import RaisedButton from 'material-ui/RaisedButton';
import Error from './error';

const styles = {
  errorStyle: {
    color: "orange500",
  },
  underlineStyle: {
    borderColor: "rgba(255, 255, 255, 0.5)",
  },
  underlineFocusStyle: {
	borderColor: "white"
  },
  floatingLabelStyle: {
  	fontWeight: "normal",
    color: "rgba(255, 255, 255, 0.5)",
  },
  floatingLabelFocusStyle: {
  	fontWeight: "normal",
    color: "rgba(255, 255, 255, 0.5)",
  },
};
var lang = DataFormatter.getLanguage();


class LoginForm extends React.Component {
 constructor() {
    super();
    //Bind events for es6 syntax
    this.hideShowPassword = this.hideShowPassword.bind(this);
    this.resizeWindow = this.resizeWindow.bind(this);
  }

resizeWindow = function(){
  if((false || !!document.documentMode) ) {
    var winWidth = window.innerWidth;
    document.querySelector('.show_password').style.marginLeft = ((parseInt(winWidth)/2) + 103) + "px";
  }
}

componentWillUnmount = function() {
  document.removeEventListener("resize", this.resizeWindow);
}

componentDidMount = function() {
     this.resizeWindow();
     window.scrollTo(0,0);
     var body =  document.querySelector('body');
     body.setAttribute('style', 'overflow-x: hidden !important');
     window.onresize = function(){
      if(false || !!document.documentMode ) {
          var winWidth = window.innerWidth;
          document.querySelector('.show_password').style.marginLeft = ((parseInt(winWidth)/2) + 103) + "px";
        }
     }
  }

  render() {
    return (
		<div className="wrapper">
				<div className="loginContainer">
					<div id="formContainer" className="formcontrol">
						<form id="loginForm" onSubmit={this.validate} autoComplete="off">	
            <div className="readerplus_logo">
                <svg height="100" width="100">  
              <circle cx="50" cy="50" r="35" stroke="white" strokeWidth="3" fill="white"></circle>
              <text x="33" y="60" fontWeight="bold" fontFamily="Roboto, san-serif" fontSize="28" fill="#007ea5" >R+</text>
                </svg>
            </div>
            <div>
            <label id="logo_title" className="logo_title">Reader Plus</label>
            </div>
            <div id="error_login" className="error_login">
            <Error fontstyleDD={this.props.FontStyle} contentDD={this.props.ErrorTxt}/>
            </div>
							<div>
							<TextField autoComplete="off" floatingLabelText={DataFormatter.getObjectText(Localization, (lang + ".PageText.UserName"))} className="username" id="username" type="text" floatingLabelStyle={styles.floatingLabelStyle} floatingLabelFocusStyle={styles.floatingLabelFocusStyle} underlineFocusStyle={styles.underlineFocusStyle} underlineStyle={styles.underlineStyle} /><br />
							 </div>
               <div>
               <image onClick={this.hideShowPassword} className= "show_password" src="/assets/images/showPasswordW.png"> </image>
               </div>
							 <div>
								<TextField floatingLabelText={DataFormatter.getObjectText(Localization, (lang + ".PageText.PassWord"))} className="password" name="password" id="password" type="password" floatingLabelStyle={styles.floatingLabelStyle} floatingLabelFocusStyle={styles.floatingLabelFocusStyle} underlineFocusStyle={styles.underlineFocusStyle} underlineStyle={styles.underlineStyle} /><br />
							 </div>
							 <div>
							    <RaisedButton id="login_submit" type="submit" className="btn-lg" label={DataFormatter.getObjectText(Localization, (lang + ".PageText.Login"))} />
							 </div>				
						</form>	            
					</div>
				</div>	
		</div>			
    );
  }
  
  validate = function(e){
	  AppActions.loginValidate(e);
  }

  hideShowPassword = function(){
    if(document.querySelector('.password input')){
      var element = document.querySelector('.password input');
      var currentType = element.getAttribute("type");
      if(String(currentType) == "password") {
       element.setAttribute("type", "text");  
      }else{
        element.setAttribute("type", "password");
      }
      
    }
  }

};

export default LoginForm;





