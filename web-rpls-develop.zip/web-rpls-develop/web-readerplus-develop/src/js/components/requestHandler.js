import request from 'superagent';
import AppConstants from '../constants/app.constants';
import AppDispatcher from '../dispatchers/app.dispatcher';
import AppActions from '../actions/app.actions';
import ErrorConstants from '../constants/error.constants';
import DataFormatter from './utilities/dataFormatter';
import Localization from './localization';


var lang = DataFormatter.getLanguage();

class RequestHandler
{
  callback = null;
  constructor()
  {
    this.handleError = this.handleError.bind(this);
    this.requestCompleted = this.requestCompleted.bind(this);
  }
  handleError = function(err) {
    if(err.status === 401 || err.status === 403) {
      AppActions.logoutUser({
        action:"unauthorized",
        message:DataFormatter.getObjectText(Localization, (lang + ".ErrorConstants.SessionExpired"))
      });
    }
    else {
      //handle other errors here
    }
    // Dispatch an action saying that an error has occurred
    AppDispatcher.dispatch({
      type : AppConstants.ActionTypes.APP_ERROR,
      data : err.response.body
    });
  }
  handleRequest = function(requestType,requestURL,headerParameters,requestParameters,callbackFn,contentType) {
    var serverRequest = request;
    this.callback = callbackFn;
    switch(requestType) {
      case AppConstants.RequestTypes.get:
      serverRequest = serverRequest.get(requestURL)
      break;
      case AppConstants.RequestTypes.post:
      serverRequest = serverRequest.post(requestURL)
      break;
      case AppConstants.RequestTypes.put:
      serverRequest = serverRequest.put(requestURL)
      break;
      case AppConstants.RequestTypes.head:
      serverRequest = serverRequest.head(requestURL)
      break;
      case AppConstants.RequestTypes.delete:
      serverRequest = serverRequest.delete(requestURL)
      break;
      default:
      serverRequest = serverRequest.get(requestURL)
      break;
    }
    // Append content type to the request only if its present.
    if(contentType) {
      serverRequest.type(contentType);
    }
      serverRequest.set(headerParameters)
      .send(requestParameters)
      .set('Accept', 'application/json')
      .end(this.requestCompleted)
  }
  requestCompleted = function(err,res) {
    if(err && location.pathname.trim() !=='/') {
      this.handleError(err);
    }
    else {
      if(DataFormatter.isFunction(this.callback))
      {
        this.callback(err,res);
      }
    }
  }
};
export default RequestHandler;
