import React from 'react';
import AppConstants from '../constants/app.constants';
import Error from './error';

let imageUrl = "";
class BookmarkLink extends React.Component {	
	constructor() {
    super();
    //Bind events for es6 syntax
    this.bookmarkLinkClicked = this.bookmarkLinkClicked.bind(this);
  }

 state = {
 	isBookmarked: false
 } 
componentDidUpdate = function() {
	if(this.props.isBookmarked !== this.state.isBookmarked)
	this.setState({
		isBookmarked: this.props.isBookmarked
	})
}
bookmarkLinkClicked = function(bookmark,event) {
	if(this.state.isBookmarked)
	{	console.log("Change State to False");
		this.setState({
		 isBookmarked: false
		});
	} else {
		console.log("Change State to True");
		this.setState({
		 isBookmarked: true
		});
	}
	event.preventDefault();  
}

render = function() {
	if (this.state.isBookmarked === true) {
        imageUrl = 'assets/images/bookmark-selected.png';
    } else {
       	imageUrl = 'assets/images/bookmark.png';
    }
    return (       
		<div>
		<img id="link_bookmark" className = "link_bookmark "alt="" src={imageUrl} width="26" height="30" ALIGN="RIGHT" onmouseover="this.style.cursor='pointer'" onClick={this.bookmarkLinkClicked.bind(this,AppConstants.BookHeaderOptions.BOOKMARK)}/>
		</div>	
              	
    );
  }
};
export default BookmarkLink;