import React from 'react';
import Slider from 'bootstrap-slider';
import {Navbar, Nav, MenuItem, NavItem, DropdownButton,ButtonToolbar} from 'react-bootstrap';
import DataFormatter from './utilities/dataFormatter';
import Localization from './localization';

var lang = DataFormatter.getLanguage();

let sliderObj, sliderOptions = {};
let oldSliderValue = 1;

class Accessibility extends React.Component {
 
    constructor() {
    super();  
    //Bind events for es6 syntax
    this.increaseFontSize = this.increaseFontSize.bind(this);
    this.decreaseFontSize = this.decreaseFontSize.bind(this);
    this.setState = this.setState.bind(this);
  } 
   state = {   
    fontSize: ""
  }; 

	componentDidMount = function() {  
  this.createFontSettings();
  window.fontSettings.initialize();
	document.querySelector('.accessibilityContainer').style.visibility = "hidden";
  var fontfamily   = DataFormatter.getObjectInStorage('fontfamily');
      if(fontfamily!=null)
      {
        try {

      var font = document.getElementById('fontstyle');
      var opts = font.options.length;
       for (var i=0; i<opts; i++){
        if (font.options[i].value == fontfamily){
            font.options[i].selected = true;
        }
      }
    }catch(e){}

    }
     var fonttheme   = DataFormatter.getObjectInStorage('fonttheme');
      if(fonttheme!=null)
      {
       
      var font = document.getElementById('fontcontrast');
      var opts = font.options.length;
       for (var i=0; i<opts; i++){
        if (font.options[i].value == fonttheme){
            font.options[i].selected = true;
        }
      
    }
	}
}
	render() {
		// Cater to an absolute or percentage value.
		// Render only if the slider is supposed to be rendered.
	
			return (
			<div className = 'accessibilityContainer'>
				<div className='fontContainer'>        
       				
				<text><b>T&nbsp;&nbsp;</b></text>
				<select id="fontstyle" onChange={this.changeFontStyle} >
          			 <option value="Times New Roman">{DataFormatter.getObjectText(Localization, (lang + ".AccesibilityText.Original"))}</option>          			 
           			 <option value="Arial">{DataFormatter.getObjectText(Localization, (lang + ".AccesibilityText.Arial"))}</option>
          			 <option value="Courier">{DataFormatter.getObjectText(Localization, (lang + ".AccesibilityText.Courier"))}</option> 
          			 <option value="Times New Roman">{DataFormatter.getObjectText(Localization, (lang + ".AccesibilityText.Times"))}</option>        
    				</select>
   					 </div>

             <div className='fontContrastContainer'>        
               <image src="assets/images/ic_action_brightness.png"  width="25" height="27" />
               <select id="fontcontrast" onChange={this.ChangeFontContrast}  >
                 <option  value="Default">{DataFormatter.getObjectText(Localization, (lang + ".AccesibilityText.Default"))}</option>
                 <option  value="Night">{DataFormatter.getObjectText(Localization, (lang + ".AccesibilityText.Night"))}</option>
                 <option  value="Sepia">{DataFormatter.getObjectText(Localization, (lang + ".AccesibilityText.Sepia"))}</option>                    
            </select> 
             </div>
             <div className ='fontSizeContainer'>
             <div className = "fontSizeStatus" id = "fontSizeStatus" >        
             <button type= "increase" className="inc"onClick={this.decreaseFontSize}><h6>A</h6></button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
             <span class="curPercentage"style={{color: 'white'}}>{this.getFontSize()}{"%"}</span>&nbsp;&nbsp;&nbsp;&nbsp;<button type= "decrease" className="dec" onClick={this.increaseFontSize}><h4>A</h4></button>           
             </div>
             </div>
   					 </div>);
	
	return null;
}
/*
Clean up slider instances.
*/
componentWillUnmount() {

}
/*
This method is fired when the user changes the Font Style.
*/
changeFontStyle = function (selectTag) { 
     this.setState({value: selectTag.target.value});

     var body= document.querySelector(".bookFrame").contentWindow.document.getElementsByTagName("body")[0];
     body.setAttribute('style',body.getAttribute('style')+'font-family: "'+selectTag.target.value+'";');
    var elements= body.getElementsByTagName("h1");
    for (var i = elements.length - 1; i >= 0; i--) {
    	elements[i].setAttribute('style',body.getAttribute('style')+'font-family: "'+selectTag.target.value+'";');
    }
     var elements= body.getElementsByTagName("span");
    for (var i = elements.length - 1; i >= 0; i--) {
      elements[i].setAttribute('style',body.getAttribute('style')+'font-family: "'+selectTag.target.value+'";');
    }
    var elements= body.getElementsByTagName("p");
    for (var i = elements.length - 1; i >= 0; i--) {
      elements[i].setAttribute('style',body.getAttribute('style')+'font-family: "'+selectTag.target.value+'";');
    }
  window.fontSettings.apply(); 
      document.querySelector('.accessibilityContainer').style.visibility = "hidden";    
     DataFormatter.setObjectInStorage("fontfamily", selectTag.target.value);
  }

/*  This function is fired when the user changes the Font contrast dropdown.*/
 ChangeFontContrast = function() {
    var body = document.querySelector(".bookFrame").contentWindow.document.getElementsByTagName("body")[0];
    var select = document.getElementById('fontcontrast');
    var fonttheme = select.value;
    var font = select.value;   
    DataFormatter.setObjectInStorage("fonttheme", fonttheme);   
    body.style.color = font;
    if (fonttheme && font== "Night") {
       window.fontSettings.setTheme("Night");
       window.fontSettings.apply(); 
    } 
    else if (fonttheme && font == "Sepia") {
      window.fontSettings.setTheme("Sepia");
      window.fontSettings.apply();
              
    } else {  
     var defaultColor = DataFormatter.getObjectInStorage("defaultColor");
     var defaultBackgroundColor = DataFormatter.getObjectInStorage("defaultBackgroundColor");
      window.fontSettings.color = defaultColor;
      window.fontSettings.backgroundColor=defaultBackgroundColor;
      window.fontSettings.apply();          
     }
      document.querySelector('.accessibilityContainer').style.visibility = "hidden"; 
      DataFormatter.setObjectInStorage("fonttheme", fonttheme);
}

createFontSettings = function() {
    if (window.fontSettings)
        return;
    window.fontSettings = new(function() {

        this.initialize = function() {
          var fs = DataFormatter.getObjectInStorage("fontsize") || false;
            if (!fs) {
              
                this.fontSize = 100;
                DataFormatter.setObjectInStorage("fontsize", this.fontSize);
              } else {
                 window.fontSettings.fontSize = parseInt(fs); 
                this.fontSize = parseInt(fs);
              }           
        }
        this.setTheme = function(theme) {
            switch (theme) {
                case "Sepia":
                    {
                        this.color = "#673403";
                        this.backgroundColor = "#fbeecf";
                        break;
                    }
                case "Night":
                    {
                        this.color = "#666666";
                        this.backgroundColor = "#222222";
                        break;
                    }               
            }
        }
        this.apply = function() {
           var fonttheme = DataFormatter.getObjectInStorage("fonttheme") || false;
         if(fonttheme) {
           this.setTheme(fonttheme);
         }
           var body = document.querySelector('.bookFrame').contentWindow.document.body;
           body.setAttribute("style", "color:" + this.color + "!important;background-color: " + this.backgroundColor + " !important");
           $(body).css("font-size", this.fontSize + '%');
           var labels = $(body).find('.label,.number,h1');
           labels.css("background-color", this.backgroundColor);
           labels.css("color", this.color);
           $(body).find('a').children().css( "background-color", "" );
           $(body).find('p').children().css( "background-color", "" );
           $(body).find('li','td','sup').children().css( "background-color", "" );
           $(body).find('p').css( "background-color", "" );
           $(body).find('p',).css( "color", this.color );
           $(body).find('li',).children().css( "color", this.color );
           $(body).find('li',).css( "color", this.color );
           $(body).find('.line','.upbold','.bold').css( "background-color", "" ); 
           $(body).find('.bold').css( "color", this.color);
           $(body).find('.strong').css( "background-color", "" );  
           $(body).find('.emphasis').css( "background-color", "" );         
           var highlightElement = document.querySelector(".bookFrame").contentWindow.document.getElementsByClassName("highlight");
           for(var i=0; i<highlightElement.length; i++) {
             highlightElement[i].setAttribute("style", "background-color:yellow !important;");
           }
            
        }
        this.increaseFontSize = function(value) {
           var currentFontSize =  window.fontSettings.fontSize;
             if(currentFontSize  < 130){
             currentFontSize+=value;
             this.fontSize+=value;
            
            }
            this.apply();
        }
        this.decreaseFontSize = function(value) {
          var currentFontSize =  window.fontSettings.fontSize;
               if(currentFontSize > 70){
               currentFontSize-=value;
               this.fontSize-=value;
             
            }
            this.apply();
        }
    })();
}
getFontSize =function(){
  if (window.fontSettings){
    return window.fontSettings.fontSize;    
  }
  return 100;
}

increaseFontSize = function() {
window.fontSettings.increaseFontSize(15);
DataFormatter.setObjectInStorage("fontsize", window.fontSettings.fontSize);
  this.setState({
                fontSize : window.fontSettings.fontSize
               });
               }    
decreaseFontSize = function(){
  window.fontSettings.decreaseFontSize(15); 
  DataFormatter.setObjectInStorage("fontsize", window.fontSettings.fontSize);
    this.setState({
                fontSize : window.fontSettings.fontSize
               });
}
};
export default Accessibility;
