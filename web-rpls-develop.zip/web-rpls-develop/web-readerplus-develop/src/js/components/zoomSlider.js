import React from 'react';
import Slider from 'bootstrap-slider';
import DataFormatter from './utilities/dataFormatter';

let sliderObj, sliderOptions = {};
let oldSliderValue = 1;

class ZoomSlider extends React.Component {
	state = {
		maxValue: 2
	};
	componentDidUpdate = function() {
		// Create an instance only when the slider is to be shown.
		if (this.props.isZoomSliderShown) {
			if (!sliderObj || Object.keys(sliderObj).length === 0) {
				sliderOptions.id = this.props.zoomSliderID;
				sliderOptions.step = this.props.zoomStep;
				sliderOptions.isPercentageSlider = this.props.isPercentageSlider;
					sliderOptions.max = 2;
					sliderOptions.min = 1;
					sliderOptions.value = this.props.zoomSliderValue * 100;
		 		// Formatting function that will determine the slider text.
				sliderOptions.formatter = function(value) {
					document.getElementById("curProgress").textContent = parseInt(value * 100);
					if (!sliderOptions.isPercentageSlider) {
						return parseInt(value * 100) + " %";
					}
					else {
						return value + "% of book navigated";
					}
				}
				this.setState({
					maxValue: sliderOptions.max
				})
				// Initiate the slider.
				sliderObj = new Slider("#" + sliderOptions.id, sliderOptions);
				sliderObj.on('slideStop', this.zoomChanged);
		
		   } // Else listen for a value change and set if required.
			else {
				// Update slider value only if the value is different from the old value.
				if (oldSliderValue !== this.props.zoomSliderValue) {
					oldSliderValue = this.props.zoomSliderValue;
					sliderObj.setValue(this.props.zoomSliderValue);
				}
			}
	   }
	}
	render() {
	  // Render only if the slider is supposed to be rendered.
		if (this.props.isZoomSliderShown) {
			return ( < div className = "zoomBar" >				
			< div className = "sliderContainer" >
			< input id = {
				this.props.zoomSliderID
			}
			type = "text" / >
			< div className = "sliderStatusMsg" id = "sliderStatusMsg" >
			<span id = "curProgress" ></span>{ "%"}</div>
			< /div>
			</div >
		);
	}
	return null;
}
/*
Clean up slider instances.
*/
componentWillUnmount() {
	 sliderObj = sliderOptions = {};
	 oldSliderValue = 1;
}
/*
This method is fired when the user stops moving the
slider handle to set a new value.
*/
zoomChanged = (valueObj) => {
	// Trigger the callback method.
	if (DataFormatter.isFunction(this.props.valueChangedCallback)) {		
		this.props.valueChangedCallback(valueObj);
	}
}
};
export default ZoomSlider;
