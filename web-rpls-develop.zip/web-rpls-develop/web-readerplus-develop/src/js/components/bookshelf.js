import React from 'react';
import AppActions from '../actions/app.actions';
import AppStore from '../stores/app.store';
import AppConstants from '../constants/app.constants';
import Book from './bookshelfItem';
import DataFormatter from './utilities/dataFormatter'

class Bookshelf extends React.Component {

  constructor() {
    super();
    //Bind events for es6 syntax
    this.bookshelfDataFetched = this.bookshelfDataFetched.bind(this);
  }
  state = {
    books:[]
  };
  /*
  This method hides or shows the body scroll bar based
  on a condition.
  */
  manageBodyScroll = function(hideScroll)
  {
    if(hideScroll) {
      // Hide the body scroll and set the window scroll to the top.
      document.body.style.overflow = 'hidden';
      window.scrollTo(0,0);
    }
    else {
      document.body.style.overflow = 'visible';
    }
  }  
  componentDidMount = function() {
    var body =  document.querySelector('body');
     body.setAttribute('style', 'overflow: hidden');
    var userId = String(DataFormatter.getKeyFromObject("userInformation", "id"));
    DataFormatter.createAWSSession();
    DataFormatter.sendAWSEvent("screen", { "action": "open" , "name" : "bookshelf" , "user_id": userId});
    this.manageBodyScroll(true);
    AppStore.on(AppConstants.EventTypes.BOOKSHELF_LOAD_COMPLETE, this.bookshelfDataFetched);
    this.resize();
    window.onresize = this.resize;
    AppActions.loadBookshelf();
  }
  componentWillMount = function() {
    if(DataFormatter.getObjectInStorage('currentBook') == null && DataFormatter.getObjectInStorage('curbookpageno') !== null){
      localStorage.removeItem('curbookpageno');
    }
  }
  renderItems = function()
  {
    return this.state.books.map(function(book,index)
    {
      //This should be removed once page implementation is done on the api side.
      //var uniqueID = Math.random().toString(36).substring(7);
      return <Book key ={book.id} book={book} />;
    });
  }
  render = function() {
    return (
      <div className ='bookshelfMasterContainer'>
      <div  className ='bookshelfContent'>
        {this.renderItems()}
      </div>
      </div>
    );
  }
  bookshelfDataFetched = (data) => {
    var sortedBooks = DataFormatter.sortList(this.state.books.concat(AppStore.response),AppConstants.SortType.ASC,"title")
    this.setState({books:sortedBooks});
    DataFormatter.setObjectInStorage('products', AppStore.response);
    DataFormatter.wrapMultipleLines('bookName');
  }
  resize = function() {
     var windowWidth = window.innerWidth;
    if(document.querySelector('.readerplus_appbar')){
      document.querySelector('.readerplus_appbar').style.width = windowWidth + "px";
      if((Object.prototype.toString.call(window.HTMLElement).indexOf('Constructor') > 0))
      document.querySelector('.navbar_right_icon').style.padding = "0px 0px 0px " +(windowWidth - 200) +"px"      
    }
    var containerHeight = 0;
    if(document.querySelector('.readerplus_appbar'))
     containerHeight = document.querySelector('.readerplus_appbar').clientHeight;
     var windowHeight = window.innerHeight;
     if(document.querySelector('.bookshelfMasterContainer')) {
     document.querySelector('.bookshelfMasterContainer').style.height = windowHeight - containerHeight + "px";
   }
   var menuWidth = 100;
   if(document.querySelector('.logout_menu')) {
    try{
           menuWidth = parseInt(document.querySelector('.logout_menu div').style.width.split('px')[0]);
            
        }catch(e){

        }
        document.querySelector('.logout_menu').style.marginLeft = (windowWidth - menuWidth - 50) + "px";      
    }  
  }

componentWillUnmount() {
	AppStore.removeListener(AppConstants.EventTypes.BOOKSHELF_LOAD_COMPLETE, this.bookshelfDataFetched);  
}
};
export default Bookshelf;
