import React from 'react';
import AppStore from '../stores/app.store';
import AppConstants from '../constants/app.constants';
import LoadingOverlay from './loadingOverlay'

class InfiniteScroller extends React.Component {
  constructor() {
    super();
    //Bind events for accessing current react context in methods for ES6
    this.handleScroll = this.handleScroll.bind(this);
    this.infiniteLoadCompleted = this.infiniteLoadCompleted.bind(this);
  }
  state = {
    isInfiniteLoading: false,
    pagesRendered:0
  }
  componentDidMount = function() {
    if (this.props.scrollType !== AppConstants.InfiniteScrollTarget.Element) {
      window.addEventListener('scroll', this.handleScroll);
    }
    else {
      if (this.refs.infiniteScrollContainer !== undefined) {
        this.refs.infiniteScrollContainer.getDOMNode().addEventListener('scroll', this.handleScroll);
      }
    }
    // Hide the loading overlay when data is loaded.
    AppStore.on(this.props.successCallback,this.infiniteLoadCompleted)
    AppStore.on(AppConstants.EventTypes.APP_ERROR,this.infiniteLoadError)
  }
  componentWillUnmount = function() {
    if (this.props.scrollType !== AppConstants.InfiniteScrollTarget.Element) {
      window.removeEventListener('scroll', this.handleScroll);
    }
    else {
      if (this.refs.infiniteScrollContainer !== undefined) {
        this.refs.infiniteScrollContainer.getDOMNode().removeEventListener('scroll', this.handleScroll);
      }
    }
  }
  updateData = function() {
    /*
    Make a request only if the number of elements rendered on screen atleast match the number of elements to
    fill up the rendered pages.
    For e.g if there are 2 rendered pages and the number of records per page is 10, there should be atleast
    20 records to make another API call.
    */
    if(this.props.currentElementCount!==0 && this.props.currentElementCount >= (this.state.pagesRendered * this.props.elementsPerPage))
    {
      // Do not make a request if a request is already pending
      if (!this.state.isInfiniteLoading) {
        this.setState({
          isInfiniteLoading: true
        });

        this.props.action();
      }
    }
  }
  handleScroll = function(event) {
    if (this.props.scrollType === AppConstants.InfiniteScrollTarget.Body) {
      if (document.body.scrollHeight == document.body.scrollTop + window.innerHeight) {
        this.updateData();
      }
    }
    else {
      var scrollElement = this.refs.infiniteScrollContainer.getDOMNode();
      if (scrollElement.scrollTop >= (scrollElement.scrollHeight - scrollElement.offsetHeight)-5) {
        this.updateData();
      }
    }
  }
  infiniteLoadCompleted = function(err) {
    this.state.pagesRendered++;
    this.setState({
      isInfiniteLoading: false
    });
  }
  infiniteLoadError = function(err) {
    this.setState({
      isInfiniteLoading: false
    });
  }
  render() {
    return <div>
    <LoadingOverlay isLoading ={this.state.isInfiniteLoading}></LoadingOverlay>
    {
      React.Children.map(this.props.children, (element, idx) => {
        return React.cloneElement(element, { ref: 'infiniteScrollContainer' });
      })
    }
    </div>
  }
};
export default InfiniteScroller;
