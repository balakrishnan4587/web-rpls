import React from 'react';
import DataFormatter from '../utilities/dataFormatter';
import AppConstants from '../../constants/app.constants';
import Localization from '../localization';

var lang = DataFormatter.getLanguage();

let menuHeader ='';

class SlidingMenu extends React.Component {
  constructor() {
    super();
  }
  state = {
    isMenuVisible: false
  };

  componentDidUpdate = function() {
    // Show the menu only once.
    if(this.props.isMenuVisible && !this.state.isMenuVisible) {
      this.showMenu();
    }
  }

  /*
  Method that is used to show the menu along with event initialization
  */
  showMenu = () => {
    var userId = String(DataFormatter.getKeyFromObject("userInformation", "id"));
    this.setState({
      isMenuVisible: true
    });
    document.addEventListener("click", this.hideMenu);
    if(document.querySelector(".bookFrame") && document.querySelector(".bookFrame") !== null) {
      document.querySelector(".bookFrame").contentDocument.addEventListener("click", this.hideMenu);
    }
    //Attach events only oce for the links
    // Handle different menu types.
    switch(this.props.menuType) {
      case AppConstants.SlidingMenuTypes.TOC:
      DataFormatter.createAWSSession();
      DataFormatter.sendAWSEvent("screen", { "action": "open" , "name" : "toc" , "user_id": userId});
      menuHeader = DataFormatter.getObjectText(Localization, (lang + ".PageText.TOC"));
      // Wire up events here as SDK cannot catch content rendered in the web reader app.
      var tocLinks = document.querySelectorAll('.list_item');
      for (var linkIndex = 0; linkIndex < tocLinks.length; linkIndex++) {
        tocLinks[linkIndex].addEventListener("click",this.handleMenuItemClick);
        tocLinks[linkIndex].querySelector('.toc_link').addEventListener("click",this.handleMenuItemClick);
      }
      break;
      case AppConstants.SlidingMenuTypes.HIGHLIGHTS:
      DataFormatter.createAWSSession();
      DataFormatter.sendAWSEvent("screen", { "action": "open" , "name" : "highlights" , "user_id": userId});
      menuHeader = DataFormatter.getObjectText(Localization, (lang + ".PageText.NotesAndHighlight"));
      // Wire up events here as SDK cannot catch content rendered in the web reader app.
      var highlightPageLinks = document.querySelectorAll('a.pageIndex');
      for (var linkIndex = 0; linkIndex < highlightPageLinks.length; linkIndex++) {
        highlightPageLinks[linkIndex].addEventListener("click",this.handleMenuItemClick);
      }
      break;
      case AppConstants.SlidingMenuTypes.BOOKMARK:
      DataFormatter.createAWSSession();
      DataFormatter.sendAWSEvent("screen", { "action": "open" , "name" : "bookmarks" , "user_id": userId});
      menuHeader = DataFormatter.getObjectText(Localization, (lang + ".PageText.Bookmarks"));     
    }
  }
  /*
  Method that is used to handle the click event of the menu item
  and bubble it to the subsciber through props.
  */
  handleMenuItemClick = (event) => {
    this.destroyLinkEventListeners();
    var element;
    event.preventDefault();
    //Parent element clicked
    if(event.currentTarget.classList.contains('list_item')) {
      element = event.currentTarget.querySelector('.toc_link');
    }
    else {
      element = event.currentTarget;
    }

    // Bubble the event to the subscriber to control TOC.
    if(DataFormatter.isFunction(this.props.menuItemClicked))
    {
      this.props.menuItemClicked(element);
    }
  }

  /*
  Method that is used to hide the menu.
  */

  hideMenu = () => {
    document.removeEventListener("click", this.hideMenu);
     //Destroy the event listeners for the links.
    this.destroyLinkEventListeners();

    // Notify the parent to update its state now that the menu has closed.
    if(DataFormatter.isFunction(this.props.menuClosed))
    {
     this.props.menuClosed(this.props.menuType);
     this.setState({ isMenuVisible: false });
    }    
  }

  /*
  This method is used to destroy all event listeners for the menu links.
  */
  destroyLinkEventListeners = () => {
    // De-wire events here
    var tocLinks = document.querySelectorAll('.list_item');
    for (var linkIndex = 0; linkIndex < tocLinks.length; linkIndex++) {
      tocLinks[linkIndex].removeEventListener("click",this.handleMenuItemClick);
      tocLinks[linkIndex].querySelector('.toc_link').removeEventListener("click",this.handleMenuItemClick);
    }
    var highlightPageLinks = document.querySelectorAll('a.pageIndex');
    for (var linkIndex = 0; linkIndex < highlightPageLinks.length; linkIndex++) {
      highlightPageLinks[linkIndex].removeEventListener("click",this.handleMenuItemClick);
    }
  }

  /*
  Clean up event handlers and other code.
  */
  componentWillUnmount = () => {
    this.destroyLinkEventListeners();
  }

  // Render the content
  render = () => {
    return (
      <div className='menu'>
      <div className={(this.state.isMenuVisible ? "visible " : "") + this.props.alignment + " tocContainer"}>
      <li className = 'tocHeader'>{menuHeader}</li>{this.props.children}</div>
      </div>
    );
  }
};
export default SlidingMenu;
