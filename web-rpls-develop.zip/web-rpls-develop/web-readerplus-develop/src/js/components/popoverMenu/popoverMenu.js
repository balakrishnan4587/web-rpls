import React from 'react';
import DataFormatter from '../utilities/dataFormatter';
import AppConstants from '../../constants/app.constants';
// import {Popover} from 'react-bootstrap';
import Paper from 'material-ui/Paper';
import Divider from 'material-ui/Divider';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import injectTapEventPlugin from 'react-tap-event-plugin';

const style = {
  height: 100,
  width: 100,
  margin: 20,
  textAlign: 'center',
  display: 'inline-block',
};


class PopoverMenu extends React.Component {
  constructor() {
    super();
    // this.setPopoverClasses = this.setPopoverClasses.bind(this);
  }
  state = {
    isHighlighted: false
  }

  componentWillMount() {
    try{
    injectTapEventPlugin();  
      }catch(e){

      }
  } 
  componentDidUpdate = function() {
   if(this.props.isHighlighted){
    try{
      document.querySelector('.highlightPopoverContainer').style.width = "134px";
      document.querySelector('.addNotes').style.marginLeft = "-65%";
      document.querySelector('.takeHighlight').style.marginLeft = "34%";
      document.querySelector('.deleteHighlight').style.marginTop = "3px";
      document.querySelector('.addNotes').style.marginRight = "74%"
        }catch(e){   
        }
       }else{
         try{
           document.querySelector('.highlightPopoverContainer').style.width = "101px";
           document.querySelector('.addNotes').style.marginLeft = "-50%";
           document.querySelector('.addNotes').style.marginRight = "66%"
           document.querySelector('.takeHighlight').style.marginLeft = "50%";
        }catch(e){

        }
    }
  }
   /*
  Method that is triggered when the dialog is to be closed.
  */
  closeDialog = function(event) {
    if(DataFormatter.isFunction(this.props.closeCallback))
    {
      this.props.closeCallback(this.props.modalType, event.currentTarget);
    }
  }

  renderHighlightButton = function() {
    if(this.props.isHighlighted){
       return(<div className="takeHighlight">
      <svg width="40" height="40">
      <circle cx="15" cy="15" r="12" z-index= "10" stroke="#fac70e" strokeWidth="2" fill="white" />
         <circle cx="15" cy="15" r="8" fill="#fac70e" />
      </svg>
      <image onClick={this.closeDialog.bind(this)} className="deleteHighlight close" src="./assets/images/delete.png"></image>
      </div>);      
    }else{
       return(<div className="takeHighlight" onClick={this.higlightButtonClicked.bind(this)}>
      <svg  height="40" width="40">
      <circle cx="15" cy="15" r="10"  fill="#fac70e" />
      </svg>
      </div>);
    }
    
  }

  addNotesForHighlight = function() {
    if(this.props.isHighlighted){
      this.props.updateNoteCallback();
    }else {
      this.props.newNoteCallback();
    }
  }

  higlightButtonClicked = function(){
      this.props.newHighlighltCallback();  
  }

  // Render the content
  render = function() {
    if(this.props.isMenuVisible){
          return (
      <div className="highlightPopoverContainer">
      <MuiThemeProvider>
      <Paper className="highlightPaper" style={style} zDepth={2}> 
      <image onClick={this.addNotesForHighlight.bind(this)} className="addNotes close" src='./assets/images/noteAddW.png'></image>
      <Divider className="highlightPopoverDivider" />      
      {this.renderHighlightButton()}
      </Paper>      
      </MuiThemeProvider>      
      </div>
    );
   }else{
    return null;
   }

  }
};
export default PopoverMenu;
