import React from 'react';
import DataFormatter from '../utilities/dataFormatter';
import AppConstants from '../../constants/app.constants';
import {Popover} from 'react-bootstrap';

class PopoverMenu extends React.Component {
  constructor() {
    super();
    this.setPopoverClasses = this.setPopoverClasses.bind(this);
  }

  componentDidMount = function() {
    document.querySelector('.highlightPopoverContainer').onmousedown = function() {
      return false;
    }
  }

  /*
  Sets initial style classes for the popover menu based
  on the configuration.
  */
  setPopoverClasses = function() {
    var classList = 'popoverContainer ';
    if(!this.props.isMenuVisible) {
      classList += 'hideElement';
    }
    if(this.props.popoverClass) {
      classList += ' ' + this.props.popoverClass;
    }
    else {
      classList += ' ' + 'defaultPopoverStyle';
    }
    if(!this.props.placement.isCustomPlacement) {
      classList += ' ' + 'defaultPopoverPosition';
    }
    return classList;
  }

  // Render the content
  render = function() {
    if(this.props.isMenuVisible){
         return (      
      <div className= {this.setPopoverClasses()}>
      <Popover title={this.props.title}  placement={this.props.placement.position} positionLeft={this.props.placement.left} positionTop={this.props.placement.top}>
      {this.props.children}
      </Popover>
      </div>
    );
       }else{
        return null
       }
 
  }
};
export default PopoverMenu;
