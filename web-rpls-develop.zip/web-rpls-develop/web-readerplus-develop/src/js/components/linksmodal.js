import React from 'react';
import {Modal} from 'react-bootstrap';
import {Button} from 'react-bootstrap';
import DataFormatter from './utilities/dataFormatter';
import Localization from './localization';

class LinksModal extends React.Component {

constructor() {
    super();
    this.closePopUp = this.closePopUp.bind(this);
    this.clickLink = this.clickLink.bind(this);
  }


  componentDidMount() {
    try{
      var audioElement = document.getElementsByTagName('audio');
      audiojs.createAll({}, audioElements);      
    }catch(e){

    }
  }
  render = function() {
  	var url = this.props.linkUrl;
    if(this.props.isLinkModalShown && url !== "")
    { 
    	if(url.indexOf('.mp4') > 0 || url.indexOf('.avi') > 0 || url.indexOf('.wmv') > 0 || url.indexOf('.mpg') > 0 || url.indexOf('.mpeg') > 0) {
		    return (
		        <div className='popoutContainer'>
		        <a className='popoutCancel' onClick ={this.closePopUp.bind(this)} > Done </a>
		       	<video className = 'popoutVideo' autoPlay controls>
    					  <source src={url} type="video/mp4"> </source>
    					  Your browser does not support the video tag.
				    </video>
		        </div>
		      );
        }
    }else {
       return null;
    } 
   
  }
closePopUp = function() {
	this.props.linkCloseCallback();
}

clickLink = function() {
	document.querySelector('.openPopup').click();
}

};

export default LinksModal;