import React from 'react';
import AppActions from '../actions/app.actions';
import AppStore from '../stores/app.store';
import AppConstants from '../constants/app.constants';
import PDFPanel from './pdfPanel';
import DataFormatter from './utilities/dataFormatter'
import Localization from './localization';
import Helmet from 'react-helmet'
import Navbar from './navbar_test';
import injectTapEventPlugin from 'react-tap-event-plugin';


var lang = DataFormatter.getLanguage();

class PdfPanelContainer extends React.Component {
  state = {
    title:this.props.title
  }
  componentWillMount = function(){
       try{
    injectTapEventPlugin();  
  }catch(e){

  }   
  }

  render = function() {
    return (
      <div >
        <Helmet title={this.state.title}/>
        <Navbar/>
        <PDFPanel />
      </div>
    );
  }

  }

PdfPanelContainer.defaultProps = {
    title: DataFormatter.getObjectText(Localization, (lang + ".PageTitles.Login"))
 }

export default PdfPanelContainer;
