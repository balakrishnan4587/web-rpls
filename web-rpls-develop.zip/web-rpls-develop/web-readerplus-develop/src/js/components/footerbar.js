import React from 'react';
import DataFormatter from './utilities/dataFormatter';
import Localization from './localization';
import Slider from 'material-ui/Slider';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';

var sliderDragged = false;
var lang = DataFormatter.getLanguage();

let sliderObj, sliderOptions = {};
let oldSliderValue = 1;

class Footer extends React.Component {
	state = {
		maxValue: 0,
		minValue: 1
	};
	componentDidUpdate = function() {
		try{
			document.querySelector('.sliderBar div div').childNodes[2].style.backgroundColor = "#00b3a6";
		document.querySelector('.sliderBar div div').childNodes[0].style.backgroundColor = "#00b3a6";
			}catch(e) {

			}
	
		// Create an instance only when the slider is to be shown.
		if (this.props.isSliderShown) {
			// If the slider object is not created, then create it.
			
		}
	}
	componentDidMount = function() {
		this.setState({
			sliderValue: this.props.sliderValue
		});
			try{
			document.querySelector('.sliderBar div div').childNodes[2].style.backgroundColor = "#00b3a6";
			document.querySelector('.sliderBar div div').childNodes[0].style.backgroundColor = "#00b3a6";
				}catch(e) {

				}
	}
	render() {
			
		// Render only if the slider is supposed to be rendered.
		if (this.props.isSliderShown ) {
				
			return ( < div className = "footerBar" >
			<MuiThemeProvider>
			<Slider onDragStop={this.loadNextPage.bind(this)} id="sliderBar" min={this.state.minValue} max={this.props.totalPages} step={1} value={this.props.sliderValue} className="sliderBar">			
			</Slider>
			</MuiThemeProvider>			
			<span className="currentPage">{this.props.sliderValue}/{this.props.totalPages}</span>			
			</div >
		);
	}
	return null;
}
/*
Clean up slider instances.
*/
componentWillUnmount() {
	
}
/*
This method is fired when the user stops moving the
slider handle to set a new value.
*/
loadNextPage = () => {
	try {
		var changedSliderValue = document.querySelector('.sliderBar input').getAttribute('value');
		if (DataFormatter.isFunction(this.props.valueChangedCallback)) {
				this.props.valueChangedCallback(parseInt(changedSliderValue));
			} 
		}catch(e){

		}
	try{
	 document.querySelector('.accessibilityContainer').style.visibility = "hidden";
	}catch(e) {
  }
	
	// // Trigger the callback method.
	
}
};
export default Footer;
