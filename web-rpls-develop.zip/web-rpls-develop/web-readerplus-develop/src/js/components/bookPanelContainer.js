import React from 'react';
import AppActions from '../actions/app.actions';
import AppStore from '../stores/app.store';
import AppConstants from '../constants/app.constants';
import BookPanel from './bookPanel';
import DataFormatter from './utilities/dataFormatter'
import Localization from './localization';
import Helmet from 'react-helmet'
import Navbar from './navbar_test';

var lang = DataFormatter.getLanguage();

class BookPanelContainer extends React.Component {
  state = {
    title:this.props.title
  }

  render = function() {
    return (
      <div >
        <Helmet title={this.state.title}/>
        <Navbar/>
        <BookPanel/>
      </div>
    );
  }

  }

BookPanelContainer.defaultProps = {
    title: DataFormatter.getObjectText(Localization, (lang + ".PageTitles.Login"))
 }
export default BookPanelContainer;
