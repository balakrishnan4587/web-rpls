let ErrorConstants = {

  SessionExpired:"Your session has expired. Please login again to continue.",

  "Login":{
    'NULL_CHECK_BOTH_MESSAGE' : 'Please enter your username and password',
    'NULL_CHECK_USERNAME_MESSAGE' : 'Please enter your username',
    'NULL_CHECK_PASSWORD_MESSAGE' : 'Please enter your password',
    'FORMAT_CHECK_MESSAGE' : 'Please provide valid username',
    'SUCCESS_MESSAGE' : 'You have successfully logged in',
    'FAILURE_MESSAGE' : 'Invalid username and/or password'
  }
};
export default ErrorConstants;
