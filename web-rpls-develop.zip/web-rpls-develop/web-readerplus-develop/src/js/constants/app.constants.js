import keyMirror from 'fbjs/lib/keyMirror';

export default {
  AppID :"555db1225658d59af24baa34",
  APIBaseUrl :"https://api-qa.gls.pearson-intl.com/",
  GA_Id : "UA-53135957-5",
  AWS_Region : "us-east-1",
  AWS_COGNITO_IDENTITY_POOL_ID : "us-east-1:1261d859-7653-4b6d-84be-22a6b37f6ac3",
  AWS_APP_ID: "58be5d4d77824319b0170a7f55729757",
  //FoxitServerURL:"https://foxit-qa.gls.pearson-intl.com/foxit-webpdf-web/pc/",
  FoxitServerURL:window.location.protocol+"//"+window.location.host+"/foxit-webpdf-web/pc/",
  ElementsPerPage:10,

  UserMessages:{
    UserLoggedOut:"You have been logged out successfully."
  },
  PageTitles:{
    Login:"Login",
    Bookshelf:"My Bookshelf",
    ReadBook:"Read Book"
  },

  //Highlights related constants.
  HighlightEnginePDF: 'foxit_v2',
  HighlightEngine: 'rangy_v1',
  DefaultHighlightColor:'yellow',

  ActionTypes : keyMirror({
    INIT_DASHBOARD : null,
	  LOGIN_VALIDATE:null,
	  LOGIN_SUBMIT:null,
    GET_USER: null,
    APP_ERROR: null,
    LOGOUT_USER: null,
    BOOK_CLICKED:null,
    HEADER_ITEM_CLICKED:null,
    BRAND_CLICKED:null,
    GET_BOOK_HIGHLIGHTS:null,
    GET_BOOK_BOOKMARKS:null
  }),
  EventTypes : keyMirror({
    INIT_DASHBOARD_COMPLETE : null,
	  LOGIN_VALIDATE_COMPLETE : null,
	  LOGIN_SUBMIT_COMPLETE: null,
    GET_USER_COMPLETE: null,
    BOOKSHELF_LOAD_COMPLETE: null,
    APP_ERROR: null,
    USER_LOGOUT_COMPLETE: null,
    BOOK_CLICKED:null,
    BOOK_HEADER_ITEM_CLICKED:null,
    BRAND_CLICKED: null,
    BOOK_HIGHLIGHTS_FETCHED:null,
    BOOK_BOOKMARKS_FETCHED:null
  }),
  InfiniteScrollTarget:keyMirror({
    Body: null,
    Element: null
  }),
  RequestTypes:keyMirror({
    get: null,
    post: null,
    put: null,
    head: null,
    del: null
  }),
  SortType:keyMirror({
  ASC: null,
  DESC: null
}),
  BookHeaderOptions:keyMirror({
    COVER:null,
    CHAPTER:null,
    TOC:null,
    HIGHLIGHTS:null,
    SETTINGS:null,
    BOOKMARK:null,
    MARK:null,
    ACESSIBILITY:null,
    ZOOM100:null,
    ZOOM125:null,
    ZOOM150:null,
    ZOOM175:null,
    ZOOM200:null,
    AUDIOICON:null
  }),
  SlidingMenuTypes:keyMirror({
    TOC: null,
    HIGHLIGHTS:null,
    BOOKMARK:null,
    MARK:null,
    ACESSIBILITY:null,
    ZOOM100:null,
    ZOOM125:null,
    ZOOM150:null,
    ZOOM175:null,
    ZOOM200:null
  }),
  ModalTypes:keyMirror({
    CHAPTER: null,
    NOTES:null
  })
};
/***
LOGIN_VALIDATE - client side validation
LOGIN_VALIDATE_COMPLETE - after completing client side validation
LOGIN_SUBMIT - passing data to server
LOGIN_SUBMIT_COMPLETE - getting response (success/failure) from server
BOOKSHELF_LOAD_COMPLETE - bookshelf loading is complete
***/
