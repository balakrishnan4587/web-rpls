import LoginContainer from './components/loginContainer';
import BookshelfContainer from './components/bookshelfContainer';
import BookPanelContainer from './components/bookPanelContainer';
import PDFPanelContainer from './components/pdfPanelContainer';
import React from 'react'
import { render } from 'react-dom'
import { Router, Route, Link, browserHistory } from 'react-router'
import bookShelfProvider from './providers/bookshelfprovider';


render((
  <Router history={browserHistory}>
    <Route path="/" component={LoginContainer}/>
    <Route path="/bookshelf" component={BookshelfContainer}/>
    <Route path="/readBook" component={BookPanelContainer}/>
    <Route path="/readPDF" component={PDFPanelContainer}/>
  </Router>
), document.getElementById('main'))


