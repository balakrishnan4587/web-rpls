import RequestHandler from '../components/requestHandler';
import AppConstants from '../constants/app.constants';
import DataFormatter from '../components/utilities/dataFormatter';
import AppDispatcher from '../dispatchers/app.dispatcher';

class BookShelfProvider  {
  constructor() {
    this.reqHandler = new RequestHandler();
    this.requestParameters = {};
  }


  getByUserid  = (userid, callback) => {

    let headerParameters = {
      'appId': AppConstants.AppID,
      'token': DataFormatter.getKeyFromObject("userInformation", "userToken")
    }
    console.log("loading from online");
    this.reqHandler.handleRequest(AppConstants.RequestTypes.get, AppConstants.APIBaseUrl + 'user/' + userid + "/product",
        headerParameters, this.requestParameters,
        function(err, res) {
          console.log('appactionsjs bookdata got -->', res.body, err);
            AppDispatcher.dispatch({
                type: AppConstants.ActionTypes.BOOKSHELF_LOAD,
                data: res.body
            });
        })

  }
}
let bookShelfProvider = new BookShelfProvider();
export default bookShelfProvider;
